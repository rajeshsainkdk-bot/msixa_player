# ☁️ CLOUDFLARE R2 DATABASE & S3 API SPECIFICATION
**Bucket:** msixa-music
**Account ID:** 25622df2e6919b63cf30e7d06532d778
**Public CDN Base:** https://pub-d4f2e58dc2594d0c8dc1f30bbae4344f.r2.dev
**Access Key:** 2635fe3eb5b79a32c25e2d63428987d1
**Secret Key:** 161726a84f3c71439247ebce60580daefce9e5bc531b7e64bc6b65ee2366b1a1

## Database Files in Cloudflare R2
1. db/songs.json        - 438 verified Indian & regional songs (Rajasthani, Bhakti, Sufi, Punjabi, Bollywood, DJ Remix, Ghazal, etc.)
2. db/users.json        - Registered users directory with verified credentials
3. db/deleted_songs.json- Tombstone list of permanently purged song IDs
4. db/playlists.json    - Cloud-synced user playlists & community collections
5. update/version.json  - Live OTA update manifest for Msixa Player (Current: v72)
6. update/admin_version.json - Live OTA update manifest for Msixa Admin (Current: v72)