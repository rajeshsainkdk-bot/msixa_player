# 📲 IN-APP OTA AUTO-UPDATE ENGINE SPECIFICATION
- Live Cloud Manifests:
  - User: https://pub-d4f2e58dc2594d0c8dc1f30bbae4344f.r2.dev/update/version.json
  - Admin: https://pub-d4f2e58dc2594d0c8dc1f30bbae4344f.r2.dev/update/admin_version.json
- Checks versionCode dynamically against remote manifest
- Prompts user with What's New dialog and top glowing update banner
- Downloads APK in chunks with live percentage progress bar
- Launches native Android PackageInstaller via FileProvider without requiring Google Play Store